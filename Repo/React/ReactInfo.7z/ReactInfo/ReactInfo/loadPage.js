// JavaScript Document

function showHideDiv(what){

      document.getElementById(what).style.display=document.getElementById(what).style.display=="none"?"block":"none"
}

function load_testing(){
	document.getElementById("div1").style.display ="none"
	document.getElementById("div2").style.display ="none"
	document.getElementById("div3").style.display ="none"
	document.getElementById("div4").style.display ="none"
	document.getElementById("div5").style.display ="none"
	document.getElementById("div6").style.display ="none"
	document.getElementById("div7").style.display ="none"
	document.getElementById("div8").style.display ="none"
	document.getElementById("div9").style.display ="none"
	document.getElementById("div10").style.display ="none"
	document.getElementById("div11").style.display ="none"
	document.getElementById("div12").style.display ="none"
	document.getElementById("div13").style.display ="none"
	document.getElementById("div14").style.display ="none"
	document.getElementById("div15").style.display ="none"
	document.getElementById("div16").style.display ="none"
	document.getElementById("div17").style.display ="none"
	document.getElementById("div18").style.display ="none"
	document.getElementById("div19").style.display ="none"
	document.getElementById("div20").style.display ="none"
	document.getElementById("div21").style.display ="none"
	document.getElementById("div22").style.display ="none"
	document.getElementById("div23").style.display ="none"
	document.getElementById("div24").style.display ="none"
	document.getElementById("div25").style.display ="none"	
	 	  
}

